# ENCODEX InterSphere — Character Forge & Galaxy Docking (v0.2)

## Run

Open **ENCODEX_InterSphere_Character_Forge.html** in a recent browser. It is a **single self-contained HTML file** and uses no external JavaScript libraries or required internet connection. Browser permissions can affect downloads and file access. The app retains existing ENCODEX demo marketplace, encoding translator, source editor, world handoff preview and hardware panel.

## Character Forge

1. Select **Character Forge** from the top navigation.
2. Click **Multi-Upload Characters** (or drop files) to import several independent characters. Click any listed entry to edit that character.
3. For a sketch, use the drawing pad or import PNG/JPEG/WebP/SVG. The importer attempts to remove flat, uniform backgrounds like white paper.
4. Select **Drawing → Extruded 3D Relief** to create a real *2.5D extruded mesh* from colored foreground pixels; **Parametric 3D Avatar** to create a stylized full-volume humanoid from traits; **Avatar + Drawing Relief** to combine them; or **Imported 3D Mesh** for supported mesh imports.
5. Set name, body height, build, muscle definition, colors, wings, ears, tail, helmet, horns, role, homeworld and abilities. Simple prompt keywords set some traits (wings, elf ears, helmet, colors, etc.). Click **Generate 3D Character**.
6. Drag the 3D view to rotate, scroll to zoom. Export selected output.

### Input formats

- PNG, JPG/JPEG, WebP, SVG: rasterized drawings/sketches (canvas foreground segmentation is approximate).
- OBJ: polygon geometry; first vertices/faces triangulated; material/texture parsing is not implemented.
- STL: binary or ASCII triangular meshes.
- GLB or VRM: glTF 2.0 binary mesh preview when uncompressed first primitive is readable. Original file bytes retained in session. Some VRM humanoid metadata, morphs, animations, skins, and textures are not shown in the lightweight viewer.
- glTF: `.gltf` JSON with inline base64 buffer; separate external `.bin` or compressed mesh is not loaded.
- JSON: character trait/manifest settings.

Files max 20 MB each. Uploaded bytes and artwork are session-memory only; export your package before closing the browser. Local UI settings from the *original marketplace* have their own storage behavior.

### Output formats

- **GLB**: valid glTF 2.0 binary mesh with real triangle geometry, normals and per-vertex colors.
- **glTF**: `.gltf` JSON with embedded buffer, colors and normals.
- **OBJ**: triangle mesh with vertex RGB extension (some readers ignore OBJ vertex color).
- **STL**: binary triangular mesh for 3D-print workflows; excludes material color and requires printability checks.
- **JSON**: traits and export manifest.
- **PNG / SVG**: concept drawing, SVG includes an embedded raster PNG (not editable vector strokes).
- **ZIP**: GLB, JSON, artwork and any original uploaded asset; export package **does not automatically transfer the avatar into third-party worlds**.

**The character generation is a procedural prototype, not AI 2D-to-3D reconstruction**. Drawing relief is a 2.5D extrusion of artwork. No automatic anatomical depth inference, skeletal rigging, retargeting or source artwork interpretation beyond simple heuristics is claimed. Imported meshes are not fully editable by the parametric trait sliders; those sliders generate separate procedural geometry unless the import mode is selected.

## Open Space & Galaxy Docking

1. Click **Galaxy & Docking**, select one of six fictional star systems.
2. Initially at Onyx Reach dock: choose **Undock/Launch**, then **Engage Warp** to the selected destination.
3. The ship travels visually along the starmap and arrives in orbit. Select **Dock at Station** to secure the ship.
4. **Explore Surface** and use WASD/arrow keys to roam in the local surface simulation.
5. Select a created character and **Deploy Avatar in World**. Character representation is a lightweight scene marker; this is not a full rigged game avatar.
6. **Export Docking Manifest** generates JSON for integration planning.

No physical spacecraft guidance, live interstellar travel, real multiplayer server, remote external-world upload or third-party game interoperability is provided. Receiving games/engines need their own glTF importer, avatar controllers, networking, licensing and access permissions.

## Included schematic

The package also contains the earlier prototype **Character InterSphere Dock** reference drawings in PDF, SVG and PNG. These cover a Raspberry Pi host, touchscreen, PN532 NFC reader, peripheral interfaces, low-voltage power and modular panel concept. They are reference schematics, not certified electrical drawings or manufacturing-ready CAD.

## Local file and security notes

Files are loaded into the browser's session memory and not sent to a server in Forge/Galaxy mode. Only upload artwork and models you have rights to use. The original kiosk's optional Python server is not needed for these new features. For production use, add asset validation, secure entitlement checks, mesh processing, persistence/database, a real game-world server and engine-specific import plugins.
